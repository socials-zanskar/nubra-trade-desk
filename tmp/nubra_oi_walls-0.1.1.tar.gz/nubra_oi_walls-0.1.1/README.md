# nubra_oi_walls

`nubra_oi_walls` packages the options wall proximity scanner as a reusable Python library on top of the official Nubra Python SDK.

## Install

```bash
pip install nubra_oi_walls
```

## Usage

```python
from nubra_python_sdk.marketdata.market_data import MarketData
from nubra_python_sdk.start_sdk import InitNubraSdk, NubraEnv
from nubra_oi_walls import run_multi_wall_proximity_scan, run_wall_proximity_scan

nubra = InitNubraSdk(NubraEnv.UAT)
market_data = MarketData(nubra)

summary_df = run_wall_proximity_scan(
    market_data=market_data,
    stocks=["NIFTY", "BANKNIFTY", "RELIANCE", "HDFCBANK"],
    normalize=False,
    exchange="NSE",
)

print(summary_df)
```

For multi-wall output when `top_n > 1`:

```python
multi_df = run_multi_wall_proximity_scan(
    market_data=market_data,
    stocks=["NIFTY", "BANKNIFTY", "RELIANCE", "HDFCBANK"],
    normalize=False,
    top_n=3,
    exchange="NSE",
)

print(multi_df)
```

There is also a ready-to-run example in [quickstart.py](/C:/Projects/nubra_oi_walls/examples/quickstart.py).
That quickstart runs both DataFrame-returning functions.

## Authentication and environment

The preferred integration is to pass your existing `MarketData` object from your main Nubra session into the scan functions.

The scanner defaults to the Nubra `UAT` environment only when it has to create its own internal client. To switch that fallback behavior to live usage, set:

```powershell
$env:NUBRA_OI_WALLS_ENV = "PROD"
```

If you pass `market_data`, the package will reuse your existing Nubra session instead of creating a new one.

## Import shape

```python
from nubra_oi_walls import run_wall_proximity_scan, run_multi_wall_proximity_scan
```

## Returned data

`run_wall_proximity_scan(...)` returns the classic single-wall summary as a pandas DataFrame.

`run_multi_wall_proximity_scan(...)` returns the expanded wall candidates as a pandas DataFrame.
