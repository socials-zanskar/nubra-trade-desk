from __future__ import annotations

import math
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Iterator, Sequence
from zoneinfo import ZoneInfo

import pandas as pd

try:
    from nubra_python_sdk.interceptor.errors import BadRequestError, ServerError
except Exception:  # pragma: no cover - fallback for local tests without the SDK
    class ServerError(Exception):
        pass

    class BadRequestError(Exception):
        pass


INTRADAY_INTERVALS = {"1s", "1m", "2m", "3m", "5m", "15m", "30m", "1h"}
DAY_OR_HIGHER_INTERVALS = {"1d", "1w", "1mt"}
SUPPORTED_INTERVALS = INTRADAY_INTERVALS | DAY_OR_HIGHER_INTERVALS
MAX_SYMBOLS_PER_REQUEST = 5
DEFAULT_TIMEZONE = "Asia/Kolkata"
PRICE_SCALE = 100.0
__version__ = "0.1.1"

INTERNAL_OUTPUT_COLUMNS = [
    "symbol",
    "candle_time",
    "candle_time_str",
    "scan_status",
    "signal_summary",
    "baseline_details",
    "volume_details",
    "price_details",
    "error_message",
    "history_points",
    "baseline_points",
    "interval",
    "baseline_mode",
    "lookback_days",
    "open",
    "high",
    "low",
    "close",
    "prev_close",
    "current_volume",
    "avg_lookback_volume",
    "median_lookback_volume",
    "max_lookback_volume",
    "volume_gap",
    "vol_ratio",
    "vol_spike_pct",
    "vol_zscore",
    "lookback_high",
    "price_gap",
    "price_breakout_pct",
    "candle_change_pct",
    "candle_direction",
    "is_green",
    "is_volume_spike",
    "is_price_breakout",
    "is_volume_breakout",
]

FINAL_OUTPUT_COLUMNS = [
    "symbol",
    "candle_time",
    "current_volume",
    "average_volume",
    "volume_ratio",
]


def run_volume_breakout(
    market_data: Any,
    stocks: Sequence[str],
    lookback_days: int,
    interval: int | str,
    rank: int,
    *,
    exchange: str = "NSE",
    instrument_type: str = "STOCK",
    baseline_mode: str = "same_slot",
    lookback_candles: int | None = None,
    timezone_name: str = DEFAULT_TIMEZONE,
    convert_prices: bool = True,
    request_volume_delta: bool = False,
    request_pause_seconds: float = 0.0,
) -> pd.DataFrame:
    """
    Run a Nubra volume breakout scan and return a ranked pandas DataFrame.

    Core calculation rules:
    - For `interval < 1d`, candle volume is derived from cumulative volume.
    - If Nubra returns `cumulative_volume_delta`, it is used first for intraday bars.
    - Otherwise intraday volume is `diff(cumulative_volume)` with negative diffs
      treated as a session reset.
    - `baseline_mode="same_slot"` compares the current intraday candle volume
      with the same time-slot candle from prior sessions.
    - `baseline_mode="rolling"` compares against the previous N completed bars.

    Parameters
    ----------
    market_data:
        Initialized `MarketData` instance from `nubra_python_sdk`.
    stocks:
        List of trading symbols, for example `["RELIANCE", "TCS"]`.
    lookback_days:
        Number of prior sessions used for baseline and breakout calculations.
    interval:
        Nubra interval such as `"5m"` or an integer minute value such as `5` or `60`.
    rank:
        Maximum number of rows to return after sorting. Use `0` or a negative
        value to return the full ranked DataFrame.
    exchange:
        Exchange passed into `historical_data()`.
    instrument_type:
        Nubra historical type such as `"STOCK"`, `"INDEX"`, `"FUT"`, or `"OPT"`.
    baseline_mode:
        `"same_slot"` or `"rolling"`.
    lookback_candles:
        Used only when `baseline_mode="rolling"`. Defaults to `lookback_days`
        when omitted.
    timezone_name:
        Timezone used for candle alignment and DataFrame timestamps.
    convert_prices:
        Divide OHLC prices by 100 for display. This matches common NSE paise to
        rupee conversion.
    request_volume_delta:
        When True and the interval is intraday, the scanner first tries to
        request `cumulative_volume_delta` from Nubra. This is disabled by
        default because some environments can reject that field server-side.
    request_pause_seconds:
        Optional pause between Nubra historical requests.
    """
    normalized_symbols = _normalize_symbols(stocks)
    normalized_interval = _normalize_interval(interval)
    baseline_mode = _normalize_baseline_mode(baseline_mode)
    lookback_days = _validate_positive_int(lookback_days, "lookback_days")
    rank = int(rank)

    if baseline_mode == "rolling":
        lookback_candles = (
            _validate_positive_int(lookback_candles, "lookback_candles")
            if lookback_candles is not None
            else lookback_days
        )
    else:
        lookback_candles = None

    if not normalized_symbols:
        return pd.DataFrame(columns=FINAL_OUTPUT_COLUMNS)

    zone = ZoneInfo(timezone_name)
    request_window_days = _estimate_request_window_days(
        lookback_days=lookback_days,
        interval=normalized_interval,
    )
    end_dt_local = datetime.now(zone)
    start_dt_local = end_dt_local - timedelta(days=request_window_days)

    rows: list[dict[str, Any]] = []

    for symbol_batch in _chunked(normalized_symbols, MAX_SYMBOLS_PER_REQUEST):
        batch_frames, batch_errors = _fetch_batch_frames(
            market_data=market_data,
            symbols=symbol_batch,
            exchange=exchange,
            instrument_type=instrument_type,
            interval=normalized_interval,
            start_dt_local=start_dt_local,
            end_dt_local=end_dt_local,
            timezone_name=timezone_name,
            convert_prices=convert_prices,
            request_volume_delta=request_volume_delta,
        )

        for symbol in symbol_batch:
            if symbol in batch_errors:
                rows.append(
                    _empty_scan_row(
                        symbol=symbol,
                        interval=normalized_interval,
                        scan_status="request_failed",
                        error_message=batch_errors[symbol],
                    )
                )
                continue

            symbol_df = batch_frames.get(symbol)
            row = _build_scan_row(
                symbol=symbol,
                symbol_df=symbol_df,
                interval=normalized_interval,
                lookback_days=lookback_days,
                baseline_mode=baseline_mode,
                lookback_candles=lookback_candles,
            )
            if row is not None:
                rows.append(row)

        if request_pause_seconds > 0:
            time.sleep(request_pause_seconds)

    result_df = pd.DataFrame(rows, columns=INTERNAL_OUTPUT_COLUMNS)
    if result_df.empty:
        return pd.DataFrame(columns=FINAL_OUTPUT_COLUMNS)

    ranked_df = _rank_result(result_df)
    if rank > 0:
        ranked_df = ranked_df.head(rank)
    return _to_user_output(ranked_df.reset_index(drop=True))


def _normalize_symbols(stocks: Sequence[str] | str | None) -> list[str]:
    if stocks is None:
        raw_symbols: Sequence[str] = []
    elif isinstance(stocks, str):
        raw_symbols = [stocks]
    else:
        raw_symbols = stocks

    deduped: list[str] = []
    seen: set[str] = set()

    for stock in raw_symbols:
        symbol = str(stock).strip().upper()
        if not symbol or symbol in seen:
            continue
        seen.add(symbol)
        deduped.append(symbol)

    return deduped


def _normalize_interval(interval: int | str) -> str:
    int_mapping = {
        1: "1m",
        2: "2m",
        3: "3m",
        5: "5m",
        15: "15m",
        30: "30m",
        60: "1h",
        1440: "1d",
        10080: "1w",
        43200: "1mt",
    }

    if isinstance(interval, int):
        if interval not in int_mapping:
            raise ValueError(
                f"Unsupported integer interval: {interval}. "
                f"Supported integer minute inputs are {sorted(int_mapping)}."
            )
        return int_mapping[interval]

    raw = str(interval).strip().lower()
    if not raw:
        raise ValueError("interval cannot be empty")

    if raw.isdigit():
        return _normalize_interval(int(raw))

    alias_mapping = {
        "60m": "1h",
        "1day": "1d",
        "1wk": "1w",
        "1mo": "1mt",
        "1month": "1mt",
    }
    normalized = alias_mapping.get(raw, raw)

    if normalized not in SUPPORTED_INTERVALS:
        raise ValueError(
            f"Unsupported interval: {interval}. "
            f"Supported intervals are {sorted(SUPPORTED_INTERVALS)}."
        )

    return normalized


def _normalize_baseline_mode(baseline_mode: str) -> str:
    mode = str(baseline_mode).strip().lower()
    if mode not in {"same_slot", "rolling"}:
        raise ValueError("baseline_mode must be either 'same_slot' or 'rolling'")
    return mode


def _validate_positive_int(value: int | None, name: str) -> int:
    if value is None:
        raise ValueError(f"{name} is required")

    int_value = int(value)
    if int_value <= 0:
        raise ValueError(f"{name} must be greater than 0")
    return int_value


def _estimate_request_window_days(lookback_days: int, interval: str) -> int:
    weekend_buffer = 2 * math.ceil(lookback_days / 5)

    if interval in INTRADAY_INTERVALS:
        return lookback_days + weekend_buffer + 7

    if interval == "1d":
        return lookback_days + weekend_buffer + 7

    if interval == "1w":
        return max(lookback_days * 9, 30)

    return max(lookback_days * 35, 90)


def _chunked(items: Sequence[str], size: int) -> Iterator[list[str]]:
    for idx in range(0, len(items), size):
        yield list(items[idx : idx + size])


def _to_utc_iso(dt_local: datetime) -> str:
    dt_utc = dt_local.astimezone(timezone.utc)
    milliseconds = dt_utc.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
    return f"{milliseconds}Z"


def _fetch_batch_frames(
    market_data: Any,
    symbols: Sequence[str],
    exchange: str,
    instrument_type: str,
    interval: str,
    start_dt_local: datetime,
    end_dt_local: datetime,
    timezone_name: str,
    convert_prices: bool,
    request_volume_delta: bool,
    *,
    allow_split: bool = True,
) -> tuple[dict[str, pd.DataFrame], dict[str, str]]:
    field_sets = _historical_field_sets(
        interval=interval,
        request_volume_delta=request_volume_delta,
    )
    last_error: Exception | None = None

    for fields in field_sets:
        request = {
            "exchange": exchange,
            "type": instrument_type,
            "values": list(symbols),
            "fields": fields,
            "startDate": _to_utc_iso(start_dt_local),
            "endDate": _to_utc_iso(end_dt_local),
            "interval": interval,
            "intraDay": False,
            "realTime": False,
        }

        try:
            response = market_data.historical_data(request)
            return (
                _response_to_symbol_frames(
                    response=response,
                    interval=interval,
                    timezone_name=timezone_name,
                    convert_prices=convert_prices,
                ),
                {},
            )
        except (ServerError, BadRequestError) as exc:
            last_error = exc
            continue

    if len(symbols) > 1 and allow_split:
        merged_frames: dict[str, pd.DataFrame] = {}
        merged_errors: dict[str, str] = {}

        for symbol in symbols:
            child_frames, child_errors = _fetch_batch_frames(
                market_data=market_data,
                symbols=[symbol],
                exchange=exchange,
                instrument_type=instrument_type,
                interval=interval,
                start_dt_local=start_dt_local,
                end_dt_local=end_dt_local,
                timezone_name=timezone_name,
                convert_prices=convert_prices,
                request_volume_delta=request_volume_delta,
                allow_split=False,
            )
            merged_frames.update(child_frames)
            merged_errors.update(child_errors)

        return merged_frames, merged_errors

    error_message = _format_request_error(
        symbols=symbols,
        interval=interval,
        field_sets=field_sets,
        error=last_error,
    )
    return {}, {symbol: error_message for symbol in symbols}


def _historical_field_sets(interval: str, request_volume_delta: bool) -> list[list[str]]:
    core_fields = ["open", "high", "low", "close", "cumulative_volume"]

    if interval in INTRADAY_INTERVALS and request_volume_delta:
        return [core_fields + ["cumulative_volume_delta"], core_fields]

    return [core_fields]


def _format_request_error(
    symbols: Sequence[str],
    interval: str,
    field_sets: Sequence[Sequence[str]],
    error: Exception | None,
) -> str:
    attempted = " | ".join(",".join(fields) for fields in field_sets)
    base = (
        f"historical_data failed for {list(symbols)} at interval={interval}. "
        f"Attempted fields: {attempted}"
    )
    if error is None:
        return base
    return f"{base}. Last error: {error}"


def _response_to_symbol_frames(
    response: Any,
    interval: str,
    timezone_name: str,
    convert_prices: bool,
) -> dict[str, pd.DataFrame]:
    symbol_frames: dict[str, pd.DataFrame] = {}

    for symbol, chart in _iter_symbol_charts(response):
        frame = _chart_to_frame(
            symbol=symbol,
            chart=chart,
            interval=interval,
            timezone_name=timezone_name,
            convert_prices=convert_prices,
        )
        if not frame.empty:
            symbol_frames[symbol] = frame

    return symbol_frames


def _iter_symbol_charts(response: Any) -> Iterator[tuple[str, Any]]:
    for chart_group in getattr(response, "result", []) or []:
        for value_map in getattr(chart_group, "values", []) or []:
            for symbol, chart in value_map.items():
                yield symbol, chart


def _chart_to_frame(
    symbol: str,
    chart: Any,
    interval: str,
    timezone_name: str,
    convert_prices: bool,
) -> pd.DataFrame:
    field_series: dict[str, pd.Series] = {}
    chart_fields = [
        "open",
        "high",
        "low",
        "close",
        "cumulative_volume",
        "cumulative_volume_delta",
    ]

    for field_name in chart_fields:
        series = _points_to_series(getattr(chart, field_name, None), timezone_name)
        if not series.empty:
            field_series[field_name] = series

    if not field_series:
        return pd.DataFrame()

    frame = pd.DataFrame(field_series).sort_index()
    frame = frame[~frame.index.duplicated(keep="last")]
    frame["symbol"] = symbol
    frame["session_date"] = pd.Index(frame.index.date)
    frame["time_slot"] = frame.index.strftime("%H:%M:%S")
    frame["volume"] = _derive_candle_volume(frame, interval)

    if convert_prices:
        for price_field in ("open", "high", "low", "close"):
            if price_field in frame.columns:
                frame[price_field] = frame[price_field] / PRICE_SCALE

    return frame


def _points_to_series(points: Iterable[Any] | None, timezone_name: str) -> pd.Series:
    if not points:
        return pd.Series(dtype="float64")

    timestamps: list[int] = []
    values: list[float | int | None] = []

    for point in points:
        timestamp = getattr(point, "timestamp", None)
        value = getattr(point, "value", None)
        if timestamp is None:
            continue
        timestamps.append(timestamp)
        values.append(value)

    if not timestamps:
        return pd.Series(dtype="float64")

    index = pd.to_datetime(timestamps, unit="ns", utc=True).tz_convert(timezone_name)
    return pd.Series(values, index=index, dtype="float64")


def _derive_candle_volume(frame: pd.DataFrame, interval: str) -> pd.Series:
    cumulative_volume = frame.get("cumulative_volume")
    delta_volume = frame.get("cumulative_volume_delta")

    if interval in DAY_OR_HIGHER_INTERVALS:
        if cumulative_volume is not None:
            return cumulative_volume.astype("float64")
        if delta_volume is not None:
            return delta_volume.astype("float64")
        return pd.Series(index=frame.index, dtype="float64")

    fallback_volume = pd.Series(index=frame.index, dtype="float64")
    if cumulative_volume is not None:
        cumulative = cumulative_volume.astype("float64")
        diffed = cumulative.diff()
        fallback_volume = diffed.where(diffed.ge(0), cumulative)

    if delta_volume is None or not delta_volume.notna().any():
        return fallback_volume

    delta = delta_volume.astype("float64")
    if cumulative_volume is not None:
        delta = delta.where(delta.notna() & delta.ge(0), fallback_volume)
    else:
        delta = delta.clip(lower=0)

    return delta


def _build_scan_row(
    symbol: str,
    symbol_df: pd.DataFrame | None,
    interval: str,
    lookback_days: int,
    baseline_mode: str,
    lookback_candles: int | None,
) -> dict[str, Any] | None:
    if symbol_df is None or symbol_df.empty:
        return _empty_scan_row(symbol=symbol, interval=interval, scan_status="no_data")

    frame = symbol_df.sort_index().copy()
    if len(frame) < 2:
        return _empty_scan_row(symbol=symbol, interval=interval, scan_status="insufficient_history")

    latest = frame.iloc[-1]
    current_ts = frame.index[-1]
    current_volume = _to_float(latest.get("volume"))
    current_open = _to_float(latest.get("open"))
    current_high = _to_float(latest.get("high"))
    current_low = _to_float(latest.get("low"))
    current_close = _to_float(latest.get("close"))
    prev_close = _to_float(frame.iloc[-2].get("close"))

    if any(pd.isna(value) for value in (current_open, current_high, current_low, current_close)):
        return _empty_scan_row(
            symbol=symbol,
            interval=interval,
            scan_status="missing_price_data",
        )

    prior_bars = _select_prior_price_bars(frame, current_ts, interval, lookback_days)
    baseline_volumes = _select_baseline_volumes(
        frame=frame,
        current_ts=current_ts,
        interval=interval,
        lookback_days=lookback_days,
        baseline_mode=baseline_mode,
        lookback_candles=lookback_candles,
    )

    avg_volume = _safe_stat(baseline_volumes, "mean")
    median_volume = _safe_stat(baseline_volumes, "median")
    max_volume = _safe_stat(baseline_volumes, "max")
    std_volume = _safe_std(baseline_volumes)
    lookback_high = _to_float(prior_bars["high"].max()) if not prior_bars.empty else float("nan")

    vol_ratio = (
        current_volume / avg_volume
        if pd.notna(current_volume) and pd.notna(avg_volume) and avg_volume > 0
        else float("nan")
    )
    vol_spike_pct = (
        ((current_volume - avg_volume) / avg_volume) * 100
        if pd.notna(current_volume) and pd.notna(avg_volume) and avg_volume > 0
        else float("nan")
    )
    vol_zscore = (
        (current_volume - avg_volume) / std_volume
        if pd.notna(current_volume)
        and pd.notna(avg_volume)
        and pd.notna(std_volume)
        and std_volume > 0
        else float("nan")
    )
    price_breakout_pct = (
        ((current_close - lookback_high) / lookback_high) * 100
        if pd.notna(current_close) and pd.notna(lookback_high) and lookback_high > 0
        else float("nan")
    )
    candle_change_pct = (
        ((current_close - prev_close) / prev_close) * 100
        if pd.notna(current_close) and pd.notna(prev_close) and prev_close > 0
        else float("nan")
    )

    is_green = bool(pd.notna(current_close) and pd.notna(current_open) and current_close > current_open)
    is_volume_spike = bool(pd.notna(current_volume) and pd.notna(avg_volume) and avg_volume > 0 and current_volume > avg_volume)
    is_price_breakout = bool(
        pd.notna(current_close) and pd.notna(lookback_high) and current_close > lookback_high
    )
    is_volume_breakout = bool(is_green and is_volume_spike and is_price_breakout)

    required_baseline_points = lookback_candles if baseline_mode == "rolling" else lookback_days
    scan_status = "ok" if len(baseline_volumes) >= required_baseline_points else "insufficient_history"
    candle_direction = _candle_direction(current_open, current_close)
    volume_gap = (
        current_volume - avg_volume
        if pd.notna(current_volume) and pd.notna(avg_volume)
        else float("nan")
    )
    price_gap = (
        current_close - lookback_high
        if pd.notna(current_close) and pd.notna(lookback_high)
        else float("nan")
    )
    signal_summary = _build_signal_summary(
        scan_status=scan_status,
        is_green=is_green,
        is_volume_spike=is_volume_spike,
        is_price_breakout=is_price_breakout,
    )
    baseline_details = _build_baseline_details(
        interval=interval,
        baseline_mode=baseline_mode,
        lookback_days=lookback_days,
        lookback_candles=lookback_candles,
    )
    volume_details = _build_volume_details(
        current_volume=current_volume,
        avg_volume=avg_volume,
        vol_ratio=vol_ratio,
        vol_spike_pct=vol_spike_pct,
    )
    price_details = _build_price_details(
        current_close=current_close,
        lookback_high=lookback_high,
        price_breakout_pct=price_breakout_pct,
        candle_change_pct=candle_change_pct,
    )

    return {
        "symbol": symbol,
        "candle_time": current_ts,
        "candle_time_str": _format_timestamp(current_ts),
        "scan_status": scan_status,
        "signal_summary": signal_summary,
        "baseline_details": baseline_details,
        "volume_details": volume_details,
        "price_details": price_details,
        "error_message": pd.NA,
        "history_points": int(len(frame)),
        "baseline_points": int(len(baseline_volumes)),
        "interval": interval,
        "baseline_mode": baseline_mode,
        "lookback_days": lookback_days,
        "open": current_open,
        "high": current_high,
        "low": current_low,
        "close": current_close,
        "prev_close": prev_close,
        "current_volume": current_volume,
        "avg_lookback_volume": avg_volume,
        "median_lookback_volume": median_volume,
        "max_lookback_volume": max_volume,
        "volume_gap": volume_gap,
        "vol_ratio": vol_ratio,
        "vol_spike_pct": vol_spike_pct,
        "vol_zscore": vol_zscore,
        "lookback_high": lookback_high,
        "price_gap": price_gap,
        "price_breakout_pct": price_breakout_pct,
        "candle_change_pct": candle_change_pct,
        "candle_direction": candle_direction,
        "is_green": is_green,
        "is_volume_spike": is_volume_spike,
        "is_price_breakout": is_price_breakout,
        "is_volume_breakout": is_volume_breakout,
    }


def _select_prior_price_bars(
    frame: pd.DataFrame,
    current_ts: pd.Timestamp,
    interval: str,
    lookback_days: int,
) -> pd.DataFrame:
    if interval in DAY_OR_HIGHER_INTERVALS:
        return frame.iloc[:-1].tail(lookback_days)

    current_session = current_ts.date()
    session_dates = sorted(pd.unique(frame["session_date"]))
    previous_sessions = [session_date for session_date in session_dates if session_date < current_session]
    relevant_sessions = previous_sessions[-lookback_days:] + [current_session]
    mask = frame["session_date"].isin(relevant_sessions) & (frame.index < current_ts)
    return frame.loc[mask]


def _select_baseline_volumes(
    frame: pd.DataFrame,
    current_ts: pd.Timestamp,
    interval: str,
    lookback_days: int,
    baseline_mode: str,
    lookback_candles: int | None,
) -> pd.Series:
    volume_series = frame["volume"].dropna()

    if volume_series.empty:
        return volume_series

    if interval in DAY_OR_HIGHER_INTERVALS:
        return volume_series.iloc[:-1].tail(lookback_days)

    if baseline_mode == "rolling":
        periods = lookback_candles or lookback_days
        return volume_series.iloc[:-1].tail(periods)

    current_session = current_ts.date()
    session_dates = sorted(pd.unique(frame["session_date"]))
    previous_sessions = [session_date for session_date in session_dates if session_date < current_session]
    baseline_sessions = previous_sessions[-lookback_days:]
    time_slot = current_ts.strftime("%H:%M:%S")

    mask = frame["session_date"].isin(baseline_sessions) & (frame["time_slot"] == time_slot)
    return frame.loc[mask, "volume"].dropna()


def _empty_scan_row(
    symbol: str,
    interval: str,
    scan_status: str,
    error_message: str | None = None,
) -> dict[str, Any]:
    row = {column: pd.NA for column in INTERNAL_OUTPUT_COLUMNS}
    row.update(
        {
            "symbol": symbol,
            "interval": interval,
            "scan_status": scan_status,
            "signal_summary": _empty_signal_summary(scan_status, error_message),
            "error_message": error_message if error_message else pd.NA,
            "history_points": 0,
            "baseline_points": 0,
            "is_green": False,
            "is_volume_spike": False,
            "is_price_breakout": False,
            "is_volume_breakout": False,
        }
    )
    return row


def _to_user_output(result_df: pd.DataFrame) -> pd.DataFrame:
    user_df = pd.DataFrame(
        {
            "symbol": result_df["symbol"],
            "candle_time": result_df["candle_time_str"],
            "current_volume": result_df["current_volume"],
            "average_volume": result_df["avg_lookback_volume"],
            "volume_ratio": result_df["vol_ratio"],
        }
    )
    return user_df.loc[:, FINAL_OUTPUT_COLUMNS].reset_index(drop=True)


def _format_timestamp(timestamp: pd.Timestamp | Any) -> str:
    if timestamp is None or pd.isna(timestamp):
        return ""
    return pd.Timestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S %Z")


def _candle_direction(current_open: float, current_close: float) -> str:
    if pd.isna(current_open) or pd.isna(current_close):
        return "Unknown"
    if current_close > current_open:
        return "Green"
    if current_close < current_open:
        return "Red"
    return "Flat"


def _build_signal_summary(
    scan_status: str,
    is_green: bool,
    is_volume_spike: bool,
    is_price_breakout: bool,
) -> str:
    if scan_status != "ok":
        return _empty_signal_summary(scan_status, None)
    if is_green and is_volume_spike and is_price_breakout:
        return "Confirmed volume breakout"
    if is_volume_spike and is_price_breakout and not is_green:
        return "Price and volume crossed, but candle is not green"
    if is_volume_spike:
        return "Volume spike only"
    if is_price_breakout:
        return "Price breakout only"
    return "No breakout"


def _empty_signal_summary(scan_status: str, error_message: str | None) -> str:
    if scan_status == "request_failed":
        return f"Request failed: {error_message}" if error_message else "Request failed"
    if scan_status == "no_data":
        return "No historical data returned"
    if scan_status == "missing_price_data":
        return "Missing price data"
    if scan_status == "insufficient_history":
        return "Insufficient history"
    return scan_status


def _build_baseline_details(
    interval: str,
    baseline_mode: str,
    lookback_days: int,
    lookback_candles: int | None,
) -> str:
    if interval in DAY_OR_HIGHER_INTERVALS:
        return f"Previous {lookback_days} {interval} candles"
    if baseline_mode == "rolling":
        periods = lookback_candles or lookback_days
        return f"Rolling previous {periods} candles"
    return f"Same time-slot across previous {lookback_days} sessions"


def _build_volume_details(
    current_volume: float,
    avg_volume: float,
    vol_ratio: float,
    vol_spike_pct: float,
) -> str:
    if pd.isna(current_volume):
        return "Current volume unavailable"
    if pd.isna(avg_volume) or avg_volume <= 0:
        return f"Current {_format_number(current_volume, 0)}, baseline unavailable"
    return (
        f"Current {_format_number(current_volume, 0)} vs avg {_format_number(avg_volume, 0)} "
        f"({_format_number(vol_ratio, 2)}x, {_format_signed_pct(vol_spike_pct)})"
    )


def _build_price_details(
    current_close: float,
    lookback_high: float,
    price_breakout_pct: float,
    candle_change_pct: float,
) -> str:
    if pd.isna(current_close):
        return "Close price unavailable"
    if pd.isna(lookback_high) or lookback_high <= 0:
        return (
            f"Close {_format_number(current_close, 2)}, breakout level unavailable, "
            f"candle change {_format_signed_pct(candle_change_pct)}"
        )
    return (
        f"Close {_format_number(current_close, 2)} vs lookback high {_format_number(lookback_high, 2)} "
        f"({_format_signed_pct(price_breakout_pct)}), candle change {_format_signed_pct(candle_change_pct)}"
    )


def _format_number(value: float, decimals: int) -> str:
    if pd.isna(value):
        return "NA"
    return f"{value:,.{decimals}f}"


def _format_signed_pct(value: float) -> str:
    if pd.isna(value):
        return "NA"
    return f"{value:+.2f}%"


def _safe_stat(series: pd.Series, stat: str) -> float:
    cleaned = series.dropna()
    if cleaned.empty:
        return float("nan")
    return _to_float(getattr(cleaned, stat)())


def _safe_std(series: pd.Series) -> float:
    cleaned = series.dropna()
    if len(cleaned) < 2:
        return float("nan")
    return _to_float(cleaned.std(ddof=0))


def _to_float(value: Any) -> float:
    if value is None or pd.isna(value):
        return float("nan")
    return float(value)


def _rank_result(result_df: pd.DataFrame) -> pd.DataFrame:
    ranked = result_df.copy()
    ranked["_volume_ratio_rank"] = pd.to_numeric(
        ranked["vol_ratio"],
        errors="coerce",
    ).fillna(float("-inf"))
    ranked["_current_volume_rank"] = pd.to_numeric(
        ranked["current_volume"],
        errors="coerce",
    ).fillna(float("-inf"))

    ranked = ranked.sort_values(
        by=["_volume_ratio_rank", "_current_volume_rank", "symbol"],
        ascending=[False, False, True],
        kind="mergesort",
    )

    return ranked.drop(columns=["_volume_ratio_rank", "_current_volume_rank"])


__all__ = ["run_volume_breakout", "__version__"]
