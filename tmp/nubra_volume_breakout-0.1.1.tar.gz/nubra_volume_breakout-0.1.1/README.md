# nubra-volume-breakout

`nubra-volume-breakout` is a Python library for scanning stocks based on volume breakout using the Nubra Python SDK.

It fetches historical OHLCV data using `MarketData.historical_data(...)`, derives candle volume for intraday intervals, calculates the average lookback volume, computes:

```text
volume_ratio = current_volume / average_volume
```

and returns a ranked pandas DataFrame.

## Installation

```bash
pip install nubra-volume-breakout==0.1.1
```

## Quickstart

See [example/quickstart.py](example/quickstart.py).

```python
from nubra_python_sdk.marketdata.market_data import MarketData
from nubra_python_sdk.start_sdk import InitNubraSdk, NubraEnv
from nubra_volume_breakout import run_volume_breakout

nubra = InitNubraSdk(NubraEnv.PROD, env_creds=True)
market_data = MarketData(nubra)

stocks = ["ABB", "ADANIENSOL", "ADANIENT", "ADANIGREEN", "ADANIPORTS"]

volume_breakout = run_volume_breakout(
    market_data=market_data,
    stocks=stocks,
    lookback_days=10,
    interval="1d",
    rank=10,
)

print(volume_breakout.head())
```

## Returned DataFrame

The scanner returns only these columns:

- `symbol`
- `candle_time`
- `current_volume`
- `average_volume`
- `volume_ratio`
