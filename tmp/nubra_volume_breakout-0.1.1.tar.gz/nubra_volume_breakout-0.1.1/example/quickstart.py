from nubra_python_sdk.marketdata.market_data import MarketData
from nubra_python_sdk.start_sdk import InitNubraSdk, NubraEnv
from nubra_volume_breakout import run_volume_breakout

nubra = InitNubraSdk(NubraEnv.PROD, env_creds=True)
market_data = MarketData(nubra)

stocks = [
    "ABB",
    "ADANIENSOL",
    "ADANIENT",
    "ADANIGREEN",
    "ADANIPORTS",
    "ADANIPOWER",
    "AMBUJACEM",
    "APOLLOHOSP",
    "ASIANPAINT",
    "DMART",
    "AXISBANK",
    "BAJAJ-AUTO",
    "BAJFINANCE",
    "BAJAJFINSV",
    "BAJAJHLDNG",
    "BANKBARODA",
    "BEL",
    "BPCL",
    "BHARTIARTL",
]

volume_breakout = run_volume_breakout(
    market_data=market_data,
    stocks=stocks,
    lookback_days=10,
    interval="1d",
    rank=10,
)

print(volume_breakout.head(10))
